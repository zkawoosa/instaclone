"""Insta485 REST API."""

from insta485.api.posts import get_post
